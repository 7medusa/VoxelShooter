	┍━━━━━━━━━★━━━━━━━━━┑
	 ┬ ┬ ┌─┐ ┬   ┬   ┌─┐
	 ├─┤ ├┤  │   │   │ │
	 ┴ ┴ └─┘ ┴─┘ ┴─┘ └─┘
	┕━━━━━━━━━★━━━━━━━━━┙                               
                                 
This office asset pack was released on itch.io by MariaIsMe and is licensed under Attribution 4.0 International (CC BY 4.0). For more information regarding this license, visit this link: https://creativecommons.org/licenses/by/4.0/ 
 
Featured in this asset pack are the obj files of the following office objects:

Chairs (10 Office Chairs, 6 Couches)
Tables (16 Office Tables, 3 Coffee Tables, 12 Table Pieces)
Cubicles (5 White Cubicles, 5 Light Brown Cubicles, 5 Regular Brown Cubicles, 5 Dark Brown Cubicles, 28 Cubicle Pieces)
Misc (2 Cabinets, 2 Doors, 6 Table Decorations, 3 Plants, 2 Clocks, 5 Wall Decorations, 3 Door Pieces)
Misc Coffee (4 Coffee Machines, 2 Coffee Pots, 1 Coffee Mug, 1 "Coffee Stream")
Misc Electronics (12 Consoles and Accessories, 2 Computers, 1 Fax Machine, 1 Printer, 1 Phone, 1 Tablet, 3 TV for walls, 3 TV for Surfaces)
Misc Trashcans (4 Recycling Bins, 5 Tall Trashcans, 3 Small Trashcans)

To make or customize your own tables or cubicles, check out their respective fragments folder for easier editing.

I'd love to see what you come up with this asset pack! Share your work by tagging me on twitter ( https://twitter.com/EggnCheesePls ) or instagram ( https://www.instagram.com/alyanna.maramag/ )
If you have any questions or requests, let me know!


Thanks for downloading! 

♡ Maria
